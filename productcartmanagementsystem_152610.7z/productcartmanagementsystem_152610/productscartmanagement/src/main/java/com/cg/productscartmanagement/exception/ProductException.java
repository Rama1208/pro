package com.cg.productscartmanagement.exception;

public class ProductException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4588863550807046476L;
	
	public ProductException(String msg) {
		super(msg);
	}
}
