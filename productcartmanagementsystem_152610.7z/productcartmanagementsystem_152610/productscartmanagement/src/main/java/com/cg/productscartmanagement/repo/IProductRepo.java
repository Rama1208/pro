package com.cg.productscartmanagement.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.productscartmanagement.bean.Product;

@Repository("productrepo")
public interface IProductRepo extends CrudRepository<Product, String>{

}
