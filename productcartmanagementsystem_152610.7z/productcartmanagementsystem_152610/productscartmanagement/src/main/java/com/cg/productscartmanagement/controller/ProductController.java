package com.cg.productscartmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.productscartmanagement.bean.Product;
import com.cg.productscartmanagement.service.IProductService;





@RestController
public class ProductController {

	@Autowired
	IProductService service;
	
	@RequestMapping(value="/products", method = RequestMethod.POST)
	public void createProduct(@RequestBody Product p) {
		service.createProduct(p);
	}
	
	@RequestMapping(value="/updateproducts/{id}", method = RequestMethod.PUT)
	public void updateProduct(@RequestBody Product p, @PathVariable String id) {
		service.updateProduct(p, id);
	}
	@RequestMapping(value="/deleteproducts/{id}", method = RequestMethod.DELETE)
	public void deleteProduct(@PathVariable String id) {
		service.deleteProduct(id);
	}
	
	@RequestMapping(value="/view")
	public List<Product> viewProducts(){
		return service.viewProducts();
		
	}
	@RequestMapping(value="/findproducts/{id}", method = RequestMethod.GET)
	public Product findProduct(@PathVariable String id) {
		return service.findProduct(id);
	}


	
	
}
