package com.cg.productscartmanagement.service;

import java.util.ArrayList;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.productscartmanagement.bean.Product;
import com.cg.productscartmanagement.repo.IProductRepo;



@Service
public class ProductServiceImpl implements IProductService {
	
	@Autowired
	IProductRepo repo;
	
	@Override
	public void createProduct(Product p) {
		repo.save(p);
				
	}
	@Override
	public void updateProduct(Product p, String id) {
		repo.save(p);
		
	}
	@Override
	public void deleteProduct(String id) {
		repo.deleteById(id);
		
	}
	@Override
	public List<Product> viewProducts() {
		List<Product> list = new ArrayList<>();
		repo.findAll().forEach(list::add);
		return list;
	
	}
	@Override
	public Product findProduct(String id) {
	
		return 	repo.findById(id).get();
	}

}
