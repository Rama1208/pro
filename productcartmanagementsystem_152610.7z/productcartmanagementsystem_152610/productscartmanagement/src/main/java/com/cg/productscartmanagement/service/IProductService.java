package com.cg.productscartmanagement.service;

import java.util.List;

import com.cg.productscartmanagement.bean.Product;

public interface IProductService {

	void createProduct(Product p);

	void updateProduct(Product p, String id);

	void deleteProduct(String id);

	List<Product> viewProducts();

	Product findProduct(String id);

}
