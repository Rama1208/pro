package com.cg.productscartmanagement.bean;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan(basePackages="com.cg.productscartmanagement.productscartmanagement")
public class ProductscartmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductscartmanagementApplication.class, args);
	}
}
