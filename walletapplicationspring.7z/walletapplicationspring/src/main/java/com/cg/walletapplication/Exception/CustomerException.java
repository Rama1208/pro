package com.cg.walletapplication.Exception;

public class CustomerException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4610496947963874391L;

	public CustomerException(String msg) {
		super(msg);
	}
}
