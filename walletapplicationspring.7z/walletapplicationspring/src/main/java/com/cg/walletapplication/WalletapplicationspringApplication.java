package com.cg.walletapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class WalletapplicationspringApplication {

	public static void main(String[] args) {
		SpringApplication.run(WalletapplicationspringApplication.class, args);

	}
}
