package com.cg.spring.repo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.spring.dto.Product;

@Repository("productrepo")
public class ProductRepoImpl implements ProductRepo{

	private static List<Product>product=null;

	
	static {
		
		product=new ArrayList<>();
		Product p=new Product("S01","rama","Samsumg","150000");
		Product p1=new Product("S02","ravi","Samsumg","200000");
		Product p2=new Product("S03","ram","Samsumg","300000");
		Product p3=new Product("S04","rams","Samsumg","350000");
		Product p4=new Product("I04","rams","IPhone","50000");
		
		product.add(p);
		product.add(p1);
		product.add(p2);
		product.add(p3);
		product.add(p4);
			
		
	}
	@Override
	public List<Product> getAllProduct(){
		
		return product;
	}
	

	@Override
	public Product getProductById(String id) {
			for(Product p:product) {
				if(p.getId().equals(id)) {
					return p;
					
				}
			}
			return null;
			
	}


	@Override
	public void addProduct(Product p) {
		product.add(p);
		
	}


	@Override
	public void updateProduct(Product p,String id) {
		for(int i=0;i<product.size();i++) {
			if(product.get(i).getId().equals(id)) {
				product.set(i,p);
			}
				
		}
	}


	@Override
	public void deleteProduct(String id) {
		for(Product p:product) {
			if(p.getId().equals(id))
				product.remove(p);
}
}
}
