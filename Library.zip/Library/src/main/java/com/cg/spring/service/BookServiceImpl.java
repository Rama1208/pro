package com.cg.spring.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.beans.Book;

import com.cg.spring.repo.BookRepo;


@Service("bookservice")
public class BookServiceImpl implements BookService{
	
	@Autowired
	BookRepo repo;
	

	@Override
	public Book getBookById(int id) {
	
		return 	repo.findById(id).get();
	}


	@Override
	public void deleteBook(int id) {
		repo.deleteById(id);
		
	}

	@Override
	public void updateBook(Book b,int id) {
		repo.save(b);
		
	}

	@Override
	public void addBook(Book b) {
		repo.save(b);
		
	}


	@Override
	public Book getBook(Book book) {
	
		return repo.save(book);
	}


	@Override
	public List<Book> getAllBooks() {
	
		
		
		
			List<Book> list = new ArrayList<>();
			repo.findAll().forEach(list::add);
			return list;
			
	
	
	}

}
