package com.cg.spring.service;

import java.util.List;

import com.cg.spring.beans.Book;

public interface BookService {





	Book getBookById(int id);

	void addBook(Book b);

	void deleteBook(int id);

	void updateBook(Book b, int id);

	Book getBook(Book book);

	List<Book> getAllBooks();



}
