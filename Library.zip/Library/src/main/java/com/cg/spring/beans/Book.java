package com.cg.spring.beans;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;



@Entity
@Table(name="Book_library")

public class Book implements Serializable  {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 505279343250383848L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int bookId;
	
	private String bookAuthor;

	private String bookName;

	private String bookDept;
	
	
	public Book() {
		
	}
	
	


	public int getBookId() {
		return bookId;
	}




	public void setBookId(int bookId) {
		this.bookId = bookId;
	}




	public Book(int bookId, String bookAuthor, String bookName, String bookDept) {
		super();
		this.bookId = bookId;
		this.bookAuthor = bookAuthor;
		this.bookName = bookName;
		this.bookDept = bookDept;
	}




	public String getBookAuthor() {
		return bookAuthor;
	}

	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}

	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getBookDept() {
		return bookDept;
	}
	public void setBookDept(String bookDept) {
		this.bookDept = bookDept;
	}
	
	

}
